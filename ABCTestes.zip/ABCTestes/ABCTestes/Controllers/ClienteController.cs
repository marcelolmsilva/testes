﻿using ABCTestes.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ABCTestes.Controllers
{
    public class ClienteController : Controller
    {

        private IClientesService _clientesService;

        public ClienteController(IClientesService clientesService)
        {
            _clientesService = clientesService;
        }


        // GET: Cliente
        public ActionResult Index()
        {
            return View();
        }

        //POST: 
        [HttpPost]
       // public ActionResult Cadastro(Clientes model)
        public async Task<ActionResult> Cadastro(Clientes model)
        {
            //Valida model
            if (ModelState.IsValid)
            {
                try
                {
                    var insere = await AdicionarClientes(model);
                    ViewBag.MensagemOk = true;
                    return View("Index", model);
                }
                catch (Exception ex)
                {
                    ViewBag.MensagemOk = false;
                    ViewBag.MensagemErro = true;
                    dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                    ViewBag.Erro = sMsgErro.Message;

                   return View("Index", model);
                }

            }
            return View("Index", model);
        }

        //
        //-----------------------------------------------------------------------------------------------------------
        //Integração API
        [HttpPost]
        public async Task<JsonResult> AdicionarClientes(Clientes cliente)
        {
            await _clientesService.AdicionarClientes(cliente);
            return new JsonResult() { Data = new { Success = true } };
        }

    }
}