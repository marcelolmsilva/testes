﻿using ABCTestes.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace ABCTestes.Controllers
{
    public class VendedorController : Controller
    {

        private IClientesService _clientesService;

        public VendedorController(IClientesService clientesService)
        {
            _clientesService = clientesService;
        }


        // GET: Vendedor
        public async Task<ActionResult> Index()
        {
            try
            {
                var cliente = await ConsultarCliente(0);

                //Se Existe dados na lista ou regitro Redireciona para View Edit ->Atualizacao de dados
                if (cliente != null)
                {                   
                    return View(cliente);
                }
                else
                {
                    //Inclusão de Novo Registro
                    var modelInc = new Clientes()
                    {
                    };
                    // Se não Existe dados na lista ou registro Redireciona para View Create ->Inclusão
                    return View(modelInc);
                }
            }
            catch (Exception ex)
            {
                var modelInc = new Clientes()
                {
                };
                ViewBag.MensagemOk = false;
                ViewBag.MensagemErro = true;
                dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                ViewBag.Erro = sMsgErro.Message;

                return View("Index", modelInc);
            }

        }

        public ActionResult Novo()
        {
            return View();
        }



        //POST: 
        [HttpPost]
        public async Task<ActionResult> Cadastro(Clientes model)
        {
            //Valida model
            if (ModelState.IsValid)
            {
                try
                {
                    var insere = await AdicionarClientes(model);
                    ViewBag.MensagemOk = true;
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ViewBag.MensagemOk = false;
                    ViewBag.MensagemErro = true;
                    dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                    ViewBag.Erro = sMsgErro.Message;

                    return View("Novo", model);
                }
            }
            return RedirectToAction("Index");
        }



        //[HttpGet]
        public async Task<ActionResult> Editar(int id)
        {
            try
            {
                var cliente = await ConsultarCliente(id);

               if (cliente != null)
                {
                    return View(cliente.First());
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
                var modelInc = new Clientes()
                {};
                ViewBag.MensagemOk = false;
                ViewBag.MensagemErro = true;
                dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                ViewBag.Erro = sMsgErro.Message;
                return RedirectToAction("Index");
            }

        }

        //POST: 
        [HttpPost]
        public async Task<ActionResult> Editar(int id, Clientes model)
        {
            //Valida model
            if (ModelState.IsValid)
            {
                try
                {
                    var edita = await AtualizarClientes(id, model);
                    ViewBag.MensagemOk = true;
                    return RedirectToAction("Index");
                }
                catch (Exception ex)
                {
                    ViewBag.MensagemOk = false;
                    ViewBag.MensagemErro = true;
                    dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                    ViewBag.Erro = sMsgErro.Message;

                    return View("Editar", model);
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<int> Excluir(int id )
        {
                try
                {
                    var edita = await ExcluirClientes(id);
                    ViewBag.MensagemOk = true;
                //return RedirectToAction("Index");
                    return 1;
                }
                catch (Exception ex)
                {
                    ViewBag.MensagemOk = false;
                    ViewBag.MensagemErro = true;
                    dynamic sMsgErro = JsonConvert.DeserializeObject(ex.Message);
                    ViewBag.Erro = sMsgErro.Message;
                    //return RedirectToAction("Index");
                    return 0;
                }
        }


        //
        //-----------------------------------------------------------------------------------------------------------
        //Integração API
        //[HttpPost]

        private async Task<IEnumerable<Clientes>> ConsultarCliente(int id)
        {
            var lista = await _clientesService.ConsultarClientes(id);
            return lista;
        }

        public async Task<JsonResult> AdicionarClientes(Clientes cliente)
        {
            await _clientesService.AdicionarClientes(cliente);
            return new JsonResult() { Data = new { Success = true } };
        }

        public async Task<JsonResult> AtualizarClientes(int id, Clientes cliente)
        {
            await _clientesService.AtualizarClientes(id, cliente);
            return new JsonResult() { Data = new { Success = true } };
        }

        public async Task<JsonResult> ExcluirClientes(int id)
        {
            await _clientesService.ExcluirClientes(id);
            return new JsonResult() { Data = new { Success = true } };
        }

    }
}