
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 06/11/2018 08:00:49
-- Generated from EDMX file: C:\Users\marcelo\source\repos\ABCTestes\ABCTestes\ModelABCTestes.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[clientes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[clientes];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'clientes'
CREATE TABLE [dbo].[clientes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [CodigoCliente] nvarchar(max)  NOT NULL,
    [NomeCompleto] nvarchar(150)  NOT NULL,
    [NomeEmpresa] nvarchar(150)  NOT NULL,
    [Email] nvarchar(120)  NOT NULL,
    [CNPJ] nvarchar(15)  NOT NULL,
    [TelefoneComercial] nvarchar(20)  NOT NULL,
    [TelefoneCelular] nvarchar(20)  NOT NULL,
    [CEP] nvarchar(8)  NOT NULL,
    [Cidade] nvarchar(150)  NOT NULL,
    [Estado] nvarchar(25)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'clientes'
ALTER TABLE [dbo].[clientes]
ADD CONSTRAINT [PK_clientes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------