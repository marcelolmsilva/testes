﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace ABCTestes.Models
{
    public class Clientes
    {
        public Int32 Id { get; set; }

        [DisplayName("Código Cliente")]
        public string CodigoCliente { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Nome Completo")]
        public string NomeCompleto { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Nome Empresa")]
        public string NomeEmpresa { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("E-Mail")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("CNPJ")]
        public string CNPJ { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Telefone Comercial")]
        public string TelefoneComercial { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Telefone Celular")]
        public string TelefoneCelular { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("CEP")]
        public string CEP { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Cidade")]
        public string Cidade { get; set; }

        [Required(ErrorMessage = "Campo Obrigatório.")]
        [DisplayName("Estado")]
        public string Estado { get; set; }
    }
}