﻿using ABCTestes.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ABCTestes
{
    public interface IClientesService
    {
        Task<IEnumerable<Clientes>> ConsultarClientes(int id);
        Task AdicionarClientes(Clientes cliente);
        Task AtualizarClientes(int id, Clientes cliente);
        Task ExcluirClientes(int id);
    }

}
