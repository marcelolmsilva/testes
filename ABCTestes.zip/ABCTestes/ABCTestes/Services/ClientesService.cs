﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using ABCTestes.Models;

namespace ABCTestes.Services
{
    public class ClientesService : IClientesService
    {
        private readonly string baseUri = ConfigurationManager.AppSettings["WebApi"].ToString();
        private readonly string api = "api/clientes";
        private readonly HttpClient client = new HttpClient();

        public ClientesService()
        {
            client.BaseAddress = new Uri(baseUri + api);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<IEnumerable<Clientes>> ConsultarClientes(int id = 0)
        {
            List<Clientes> clientes = new List<Clientes>();
            Clientes cli = new Clientes();
            string getUri = "clientes/";
            if ( id > 0)
                getUri = "clientes/" + id;

            var response = await client.GetAsync(getUri);

            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStringAsync().Result;
                if (id > 0)
                {
                    cli = JsonConvert.DeserializeObject<Clientes>(result);
                    if (cli != null)
                    {
                        clientes.Add(cli);
                    }
                }
                else
                {
                    clientes = JsonConvert.DeserializeObject<List<Clientes>>(result);
                }
                    
           }
            else if (response.StatusCode.ToString() == "NotFound") 
            {
                return clientes;
            }
            else
            {
                throw new Exception(response.ReasonPhrase);
            }

            return clientes;
        }


        public async Task AdicionarClientes(Clientes cliente)
        {
            string getUri = "clientes";

            HttpResponseMessage responseMessage = await client.PostAsJsonAsync(getUri, cliente);

            if (responseMessage.IsSuccessStatusCode)
            {
                return;
            }
            var content = await responseMessage.Content.ReadAsStringAsync();

            if (responseMessage.Content != null)
                responseMessage.Content.Dispose();

            throw new Exception(content);
        }

        public async Task AtualizarClientes(int id, Clientes cliente)
        {
            string getUri = "clientes/" + id;

            HttpResponseMessage responseMessage = await client.PutAsJsonAsync(getUri, cliente);

            if (responseMessage.IsSuccessStatusCode)
            {
                return;
            }
            var content = await responseMessage.Content.ReadAsStringAsync();

            if (responseMessage.Content != null)
                responseMessage.Content.Dispose();

            throw new Exception(content);
        }

        public async Task ExcluirClientes(int id)
        {
            string getUri = "clientes/" + id;

            HttpResponseMessage responseMessage = await client.DeleteAsync(getUri);

            if (responseMessage.IsSuccessStatusCode)
            {
                return;
            }
            var content = await responseMessage.Content.ReadAsStringAsync();

            if (responseMessage.Content != null)
                responseMessage.Content.Dispose();

            throw new Exception(content);
        }


    }
}