﻿using System.Net.Http.Headers;
using System.Web.Http;

namespace ABCTestesAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        public object config { get; private set; }

        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            //Configura o retorno em Json como Default
            GlobalConfiguration.Configuration.Formatters.JsonFormatter.SupportedMediaTypes.Add(new MediaTypeHeaderValue("text/html"));
        }

    }
}
