﻿using ABCTestesAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCTestesAPI.Repository
{
    public interface IClientesRepository
    {
        IEnumerable<Clientes> GetAll();
        Clientes GetByID(int id);
        void Add(Clientes clientes);
    }
}
