﻿using ABCTestesAPI.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ABCTestesAPI.Repository
{

    public class ClientesRepository : IClientesRepository
    {

        private ClientesContext db = new ClientesContext();

        public IEnumerable<Clientes> GetAll()
        {
            return db.Clientes;
        }
        public Clientes GetByID(int id)
        {
            return db.Clientes.FirstOrDefault(p => p.Id == id);
        }
        public void Add(Clientes clientes)
        {
            db.Clientes.Add(clientes);
            db.SaveChanges();
        }

        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (db != null)
                {
                    db.Dispose();
                    db = null;
                }
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}