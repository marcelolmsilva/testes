﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ABCTestesAPI.Models
{
    public class Clientes
    {
        public Int32 Id { get; set; }
        public string CodigoCliente { get; set; }
        public string NomeCompleto { get; set; }
        public string NomeEmpresa { get; set; }
        public string Email { get; set; }
        public string CNPJ { get; set; }
        public string TelefoneComercial { get; set; }
        public string TelefoneCelular { get; set; }
        public string CEP { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
    }
}